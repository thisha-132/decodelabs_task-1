"""
DecodeLabs Data Analytics — Project 1: Data Cleaning & Preparation
Usage:
    python clean_dataset.py "Dataset for Data Analytics.xlsx"
Outputs:
    DecodeLabs_Project1_Cleaned_Data.xlsx
    cleaned_dataset.csv
This script is designed to be reproducible. It does not delete records to handle
missing CouponCode values; it labels them as "No Coupon".
"""
from pathlib import Path
import sys
import pandas as pd

input_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("Dataset for Data Analytics.xlsx")
output_dir = Path("DecodeLabs_Project1_Output")
output_dir.mkdir(exist_ok=True)

df = pd.read_excel(input_path)
rows_before = len(df)

# Trim text values.
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].map(lambda value: value.strip() if isinstance(value, str) else value)

# Normalize labels and identifiers.
for col in ["Product", "PaymentMethod", "OrderStatus", "ReferralSource"]:
    df[col] = df[col].map(lambda value: value.title() if isinstance(value, str) else value)
for col in ["OrderID", "CustomerID", "TrackingNumber", "CouponCode"]:
    df[col] = df[col].map(lambda value: value.upper() if isinstance(value, str) else value)
df["ShippingAddress"] = df["ShippingAddress"].map(
    lambda value: value.title() if isinstance(value, str) else value
)

# Dates and numeric fields.
df["Date"] = pd.to_datetime(df["Date"], errors="coerce").dt.normalize()
df["UnitPrice"] = pd.to_numeric(df["UnitPrice"], errors="coerce").round(2)
df["TotalPrice"] = pd.to_numeric(df["TotalPrice"], errors="coerce").round(2)
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce").astype("Int64")
df["ItemsInCart"] = pd.to_numeric(df["ItemsInCart"], errors="coerce").astype("Int64")

# Missing CouponCode means no coupon was recorded/used; preserve all rows.
df["CouponCode"] = df["CouponCode"].fillna("No Coupon")

# Deduplicate defensively; retain the first occurrence if any are found.
df = df.drop_duplicates()
df = df.drop_duplicates(subset=["OrderID"], keep="first").reset_index(drop=True)

# Validation checks.
assert df["OrderID"].is_unique, "Duplicate OrderID values remain."
assert df["Date"].notna().all(), "Invalid or missing dates remain."
assert df.isna().sum().sum() == 0, "Missing values remain."
assert df["TrackingNumber"].is_unique, "Duplicate TrackingNumber values remain."
assert (df["TotalPrice"].round(2) == (df["Quantity"].astype(float) * df["UnitPrice"]).round(2)).all(), \
    "TotalPrice does not match Quantity × UnitPrice."
assert len(df) == rows_before, "Unexpected row-count change; review deduplication."

csv_path = output_dir / "cleaned_dataset.csv"
xlsx_path = output_dir / "DecodeLabs_Project1_Cleaned_Data.xlsx"
df.to_csv(csv_path, index=False, date_format="%Y-%m-%d")

with pd.ExcelWriter(xlsx_path, engine="openpyxl", datetime_format="yyyy-mm-dd") as writer:
    df.to_excel(writer, sheet_name="Cleaned Data", index=False)
    pd.DataFrame([
        ["Rows", rows_before, len(df), "PASS"],
        ["Missing values", "309 in CouponCode", int(df.isna().sum().sum()), "PASS"],
        ["Duplicate OrderID values", "0 detected", int(df["OrderID"].duplicated().sum()), "PASS"],
        ["Invalid/missing dates", "0 detected after parsing", int(df["Date"].isna().sum()), "PASS"],
        ["Duplicate TrackingNumber values", "0 detected", int(df["TrackingNumber"].duplicated().sum()), "PASS"],
        ["TotalPrice mismatches", "0 detected", int((df["TotalPrice"].round(2) != (df["Quantity"].astype(float)*df["UnitPrice"]).round(2)).sum()), "PASS"],
    ], columns=["Check", "Before / Baseline", "After", "Result"]).to_excel(writer, sheet_name="Quality Audit", index=False)

print(f"Cleaned {len(df):,} rows; validation passed.")
print(f"Excel: {xlsx_path.resolve()}")
print(f"CSV:   {csv_path.resolve()}")
