DecodeLabs Data Analytics Internship — Project 1
Data Cleaning & Preparation
===============================================

FILES
- DecodeLabs_Project1_Cleaned_Data.xlsx
  Main submission workbook with four sheets:
  1. Cleaned Data
  2. Quality Audit
  3. Change Log
  4. Column Profile
- cleaned_dataset.csv
  Portable copy of the cleaned records.
- DecodeLabs_Project1_Cleaning_Report.pdf
  Summary of the cleaning approach, audit results, change log, and final validation.
- clean_dataset.py
  Reproducible cleaning script. Requires pandas, openpyxl, and the source Excel file.
- DecodeLabs_Project1_Cleaning.ipynb
  Notebook version of the workflow and validation checks.

KEY RESULTS
- 1,200 rows and 14 columns retained.
- 309 missing CouponCode values labeled "No Coupon".
- 0 missing cells after cleaning.
- 0 duplicate OrderIDs.
- 0 exact duplicate rows.
- 0 invalid or missing dates; dates standardized to YYYY-MM-DD.
- 0 duplicate TrackingNumbers.
- 0 mismatches between TotalPrice and Quantity × UnitPrice (2 decimal precision).

IMPORTANT
The task brief says to document changes and prove zero duplicate IDs and zero incorrectly formatted dates. The workbook and report include those checks. Review the deliverables before uploading to the internship portal and follow any separate naming/upload instructions from your coordinator.
